const log = document.getElementById('log');

log.addEventListener('click', function () {
    window.location.href = '/REG_LOG/log';
})