#include "includes.h"

#define BOTH_EMPTY (UART_LS_TEMT | UART_LS_THRE)


#define WAIT_FOR_XMITR \
        do { \
                lsr = REG8(UART_BASE + UART_LS_REG); \
        } while ((lsr & BOTH_EMPTY) != BOTH_EMPTY)

#define WAIT_FOR_THRE \
        do { \
                lsr = REG8(UART_BASE + UART_LS_REG); \
        } while ((lsr & UART_LS_THRE) != UART_LS_THRE)

#define TASK_STK_SIZE 256

OS_STK TaskStartStk[TASK_STK_SIZE];

char Info[103]={0xC9,0xCF,0xB5,0xDB,0xCB,0xB5,0xD2,0xAA,0xD3,0xD0,0xB9,0xE2,0xA3,0xAC,0xD3,0xDA,0xCA,0xC7,0xBE,0xCD,0xD3,0xD0,0xC1,0xCB,0xB9,0xE2,0x0D,0x0A,0xC9,0xCF,0xB5,0xDB,0xCB,0xB5,0xD2,0xAA,0xD3,0xD0,0xCC,0xEC,0xBF,0xD5,0xA3,0xAC,0xD3,0xDA,0xCA,0xC7,0xBE,0xCD,0xD3,0xD0,0xC1,0xCB,0xCC,0xEC,0xBF,0xD5,0x0D,0x0A,0xC9,0xCF,0xB5,0xDB,0xCB,0xB5,0xD2,0xAA,0xD3,0xD0,0xC2,0xBD,0xB5,0xD8,0xBA,0xCD,0xBA,0xA3,0xD1,0xF3,0xA3,0xAC,0xD3,0xDA,0xCA,0xC7,0xBE,0xCD,0xD3,0xD0,0xC1,0xCB,0xC2,0xBD,0xB5,0xD8,0xBA,0xCD,0xBA,0xA3,0xD1,0xF3,0x0D};

void uart_init(void)
{
        INT32U divisor;
 
         /* Set baud rate */
	
        divisor = (INT32U) IN_CLK/(16 * UART_BAUD_RATE);

        REG8(UART_BASE + UART_LC_REG) = 0x80;
        REG8(UART_BASE + UART_DLB1_REG) = divisor & 0x000000ff;
        REG8(UART_BASE + UART_DLB2_REG) = (divisor >> 8) & 0x000000ff;
        REG8(UART_BASE + UART_LC_REG) = 0x00;
        
        
        /* Disable all interrupts */
       
        REG8(UART_BASE + UART_IE_REG) = 0x00;
       
 
        /* Set 8 bit char, 1 stop bit, no parity */
        
       REG8(UART_BASE + UART_LC_REG) = UART_LC_WLEN8 | (UART_LC_ONE_STOP | UART_LC_NO_PARITY);
        
  
        uart_print_str("UART initialize done ! \n");
	return;
}

void uart_putc(char c)
{
        unsigned char lsr;
        WAIT_FOR_THRE;
        REG8(UART_BASE + UART_TH_REG) = c;
        if(c == '\n') {
          WAIT_FOR_THRE;
          REG8(UART_BASE + UART_TH_REG) = '\r';
        }
        WAIT_FOR_XMITR;  
  
}

void uart_print_str(char* str)
{
       INT32U i=0;
       OS_CPU_SR cpu_sr;
       OS_ENTER_CRITICAL()
       
       while(str[i]!=0)
       {
	i++;
       	uart_putc(str[i-1]);        
       }
        
       OS_EXIT_CRITICAL()
        
}

void gpio_init()
{
	REG32(GPIO_BASE + GPIO_OE_REG) = 0xffffffff;
	REG32(GPIO_BASE + GPIO_INTE_REG) = 0x00000000;
	gpio_out(0x0f0f0f0f);
	uart_print_str("GPIO initialize done ! \n");
        return;
}

void gpio_out(INT32U number)
{
	

	  REG32(GPIO_BASE + GPIO_OUT_REG) = number;
	  

}

INT32U gpio_in()
{
	INT32U temp = 0;
	

	
	 temp = REG32(GPIO_BASE + GPIO_IN_REG);
         REG32(GPIO_BASE + GPIO_IN_REG) = 0;
	  

	
	return temp;
}

/*******************************************
   
    ÉèÖÃcompareŒÄŽæÆ÷£¬²¢ÇÒÊ¹ÄÜÊ±ÖÓÖÐ¶Ï    

********************************************/
void OSInitTick(void)
{
    INT32U compare = (INT32U)(IN_CLK / OS_TICKS_PER_SEC);
    
    asm volatile("mtc0   %0,$9"   : :"r"(0x0)); 
    asm volatile("mtc0   %0,$11"   : :"r"(compare));  
    asm volatile("mtc0   %0,$12"   : :"r"(0x10000401));
    //uart_print_str("OSInitTick Done!!!\n");
    
    return; 
}

void  TaskStart (void *pdata)
{
    OSInitTick();

    int total_out = 0;
    int step = 0;
    int out_loc = 0;
    int out_state = 0;

    int turn_loc = -1;
    int turn_state = -1;

    int left_lattices = 16;

    int lattices[16];
    int content[16]={5, 2, 5, 3, 4, 3, 5, 4, 2, 2, 3, 4, 5, 3, 4, 2};
    int i=0;
    for (i=0; i<16; i++) {
        lattices[i] = 0;
        out_loc = i;
        out_state = 1;
        total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
        gpio_out(total_out);
    }

    int current_loc = 0;
    out_loc = 0;
    out_state = 6;
    total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
    gpio_out(total_out);
    
    while (1) {
        int instr_in = gpio_in();
        int up = (instr_in >> 1) & 1;
        if (up == 1) {
            step = step + 1;
            out_loc = current_loc;
            if (lattices[current_loc] == 0) {
                out_state = 1;
            }
            else if (lattices[current_loc] == 1) {
                out_state = content[current_loc];
            }
            else {
                out_state = 0;
            }
            total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
            gpio_out(total_out);
            if (current_loc <= 3) {
                current_loc = current_loc + 12;
            }
            else {
                current_loc = current_loc - 4;
            }
            out_loc = current_loc;
            if (lattices[current_loc]==0) {
                out_state = 6;
                total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
                gpio_out(total_out);
            }
            OSTimeDly(50);
        }
        int right = (instr_in >> 2) & 1;
        if (right == 1) {
            step = step + 1;
            out_loc = current_loc;
            if (lattices[current_loc] == 0) {
                out_state = 1;
            }
            else if (lattices[current_loc] == 1) {
                out_state = content[current_loc];
            }
            else {
                out_state = 0;
            }
            total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
            gpio_out(total_out);
            if (current_loc%4>=3) {
                current_loc = current_loc - 3;
            }
            else {
                current_loc = current_loc + 1;
            }
            out_loc = current_loc;
            if (lattices[current_loc]==0) {
                out_state = 6;
                total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
                gpio_out(total_out);
            }
            OSTimeDly(50);
        }
        int down = (instr_in >> 3) & 1;
        if (down == 1) {
            step = step + 1;
            out_loc = current_loc;
            if (lattices[current_loc] == 0) {
                out_state = 1;
            }
            else if (lattices[current_loc] == 1) {
                out_state = content[current_loc];
            }
            else {
                out_state = 0;
            }
            total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
            gpio_out(total_out);
            if (current_loc >= 12) {
                current_loc = current_loc - 12;
            }
            else {
                current_loc = current_loc + 4;
            }
            out_loc = current_loc;
            if (lattices[current_loc]==0) {
                out_state = 6;
                total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
                gpio_out(total_out);
            }
            OSTimeDly(50);
        }
        int left = (instr_in >> 4) & 1;
        if (left == 1) {
            step = step + 1;
            out_loc = current_loc;
            if (lattices[current_loc] == 0) {
                out_state = 1;
            }
            else if (lattices[current_loc] == 1) {
                out_state = content[current_loc];
            }
            else {
                out_state = 0;
            }
            total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
            gpio_out(total_out);
            if (current_loc%4<=0) {
                current_loc = current_loc + 3;
            }
            else {
                current_loc = current_loc - 1;
            }
            out_loc = current_loc;
            if (lattices[current_loc]==0) {
                out_state = 6;
                total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
                gpio_out(total_out);
            }
            OSTimeDly(50);
        }
        int center = instr_in & 1;
        if (center == 1) {
            step = step + 1;
            if (lattices[current_loc] == 0) {
                lattices[current_loc] = 1;
                out_state = content[current_loc];
                total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
                gpio_out(total_out);

                if (content[current_loc] == turn_state) {
                    OSTimeDly(500);
                    out_loc = turn_loc;
                    out_state = 0;
                    total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
                    gpio_out(total_out);
                    lattices[turn_loc]=2;
                    out_loc = current_loc;
                    out_state = 0;
                    total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
                    gpio_out(total_out);
                    lattices[current_loc]=2;
                    turn_loc = -1;
                    turn_state = -1;
                    left_lattices = left_lattices - 2;
                    if (left_lattices == 0) {
                        int instr_in = gpio_in();
                        int center = instr_in & 1;
                        if (center == 1) {
                            return;
                        }
                    }
                }
                else {
                    if (turn_loc != -1) {
                        out_loc = turn_loc;
                        out_state = 1;
                        total_out = (step << 16) + (out_loc << 12) + (out_state << 9);
                        gpio_out(total_out);
                        lattices[turn_loc]=0;
                    }
                    turn_loc = current_loc;
                    turn_state = content[current_loc];
                }
                OSTimeDly(50);
            }
            OSTimeDly(50);
        }
        
    }
}

void main()
{
  OSInit();
  
  uart_init();
  
  gpio_init();	
  
  OSTaskCreate(TaskStart, 
	       (void *)0, 
	       &TaskStartStk[TASK_STK_SIZE - 1], 
	       0);
  
  OSStart();  
  
}
